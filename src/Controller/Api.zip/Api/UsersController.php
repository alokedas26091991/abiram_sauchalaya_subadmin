<?php
declare(strict_types=1);
namespace App\Controller\Api;
use App\Controller\Api\AppController;
//use Cake\Event\Event;
//use Cake\Routing\Router;
//use Cake\Network\Exception\UnauthorizedException;
//use Cake\Utility\Security;
use Firebase\JWT\JWT;
use Cake\ORM\TableRegistry;
use Cake\Utility\Security;

//use Cake\Mailer\Email;
class UsersController extends AppController{
    public function initialize(): void
    {
		
        parent::initialize();
        $this->Auth->allow(['add', 'token','index','forgotPassword']);
        
    }
    /**
     * Create new user and return id plus JWT token
     */
    public function add() {
        $this->response->header('Access-Control-Allow-Origin', '*');
        $user = $this->Users->newEntity();
        if ($this->request->is('post')) {

            $user = $this->Users->patchEntity($user, $this->request->data);
            $user->create_date = date('Y-m-d H:i:s');
            if ($this->Users->save($user)) {

                $tblUserRolesObj = \Cake\ORM\TableRegistry::get('UserRoles');
                $new_entity = $tblUserRolesObj->newEntity();
                $new_entity->user_id = $user->id;
                $new_entity->role_id = 5;
                $tblUserRolesObj->save($new_entity);
                
                /*leadsqure */
              
                /*****************
                $this->loadComponent('SendMail');
                $this->SendMail->sendMail(61, $this->request->data['email_id'], ['user_id' => $user->id, 'password' => $this->request->data['password'], 'act_link' => $validation_url]);**/


                $this->set([
                    'success' => true,
                    'data' => [
                        'token' => JWT::encode([
                            'sub' => $user->id,
                            'exp' => time() + 30240000
                                ], Security::getSalt()),
                        'user_info' => $user
                    ],
                    '_serialize' => ['success', 'data']
                ]);
            } else {
                $error = \Cake\Log\Log::write('info',$user->errors());
                $emailerror = $user->errors('email');
                if (!empty($emailerror)) {
                    $msg = "Email address  already used.Please try another email address.";
                    } else {
                    $msg = "The user could not be saved. Please, try again.";
                    }

                $this->set([
                    'success' => false,
                    'data' => ['msg' => $msg],
                    '_serialize' => ['success', 'data']
                ]);
            }
        }
    }
	
	public function edit()
    {
		$user = $this->Auth->identify();
		$user = $this->Users->get($user['id'], [
            'contain' => []
        ]);
        if ($this->request->is(['patch', 'post', 'put'])) {
			
			/*if($this->request->data['occupation_id']=='others'){
				$this->request->data['occupation_id']=$this->saveOccupation($this->request->data['occupation']);
				}*/
            $user = $this->Users->patchEntity($user, $this->request->data);
            if ($this->Users->save($user)) {
				$this->loadComponent('UploadImage');
				if(isset($_FILES['photo']) && $_FILES['photo']['name']!=''){
							$userd=$this->Users->get($user['id']);
							
				 		$userd->image=$this->UploadImage->do_upload_profileimage('profileimage',$_FILES['photo'],'userProfile','ll');
					 $this->Users->save($userd);
				 }
				
				
               $userdetails= $this->Users->find('all')->where(['Users.id'=>$user['id']])->contain(['States','Cities','Occupations','PreferenceLocations'])->first();
			   
			   if(!empty($userdetails['image'])){
				   $userdetails['image']=Router::url('/upload/userProfile/thumb/'.$userdetails['image'],true); 
				   }
        $this->set([
            'success' => true,
           
                
				'userdetails'=>	$userdetails,
			"message"=> "Successfully update",
			"code"=> 200,
           
            '_serialize' => ['success', 'userdetails','message','code']
        ]);
            } else {
               $this->set([
            'success' => false,
           
                
				
			"message"=> "please try again",
			"code"=> 201,
           
            '_serialize' => ['success','message','code']
        ]);
            }
        }
    }
	
	public function changePassword(){
		$user1 = $this->Auth->identify();
		$user = $this->Users->get($user1['id'], [
            'contain' => []
        ]);
		$user->password=$this->request->data['password'];
		 if ($this->Users->save($user)) {
			  $this->set([
            'success' => true,
           	"message"=> "Password change successfully.",
			"code"=> 200,
			'token' => JWT::encode(
                    [
                        'sub' => $user1['id'],
                        'exp' =>  time() + 604800*365
                    ],
                    Security::salt()
                ),
           
            '_serialize' => ['success','message','code']
        ]);
			 }else{
				  $this->set([
            'success' => false,
           
                
				
			"message"=> "please try again",
			"code"=> 201,
           
            '_serialize' => ['success','message','code']
        ]);
				 
				 }
		}
	
	public function sendmailuser($userData,$mailData, $mailtype=1)
    {
 


				try {
				$Email = new Email();
				$Email->from(array('noreply@keneo.com' => 'Registeration'));
				$Email->emailFormat('html');
				$Email->to($userData->email);
				$Email->subject($mailData['subject']);
				$Email->send($mailData['body']);
				
				} catch (Exception $e) {
				
				echo 'Exception : ',  $e->getMessage(), "\n";
				
				}

    }
    /**
     * Return JWT token if posted user credentials pass FormAuthenticate
     */
    public function token()
    {
       // echo "bal";
       // die;
        $user = $this->Auth->identify();
		
        if (!$user) {
             $this->set([
            'success' => false,
            'data' => [
               
			"message"=> "Email or Password is incorrect",
			"code"=> 200
            ],
            '_serialize' => ['success', 'data']
        ]);
        }else{
		$userdetails= $this->Users->find('all')->where(['Users.id'=>$user['id']])->contain([])->first();
		
        $this->set([
            'success' => true,
            'data' => [
                'token' => JWT::encode(
                    [
                        'sub' => $user['id'],
                        'exp' =>  time() + 604800*365
                    ],
                    Security::getSalt()
                ),
				'userdetails'=>	$userdetails,
			"message"=> "Successfully login",
			"code"=> 200
            ],
            '_serialize' => ['success', 'data']
        ]);
		}
    }
    
    public function index(){
		
        $users=$this->Users->find('all');
        $this->set([
            'success' => true,
            'data' => [
                'users' => $users
            ],
            '_serialize' => ['success', 'data']
        ]);
    }
	public function profileDetails(){
		$user = $this->Auth->identify();
        $users= $this->Users->find('all')->where(['Users.id'=>$user['id']])->contain(['States','Cities','Occupations','PreferenceLocations'])->first();
		if(!empty($users['image'])){
				   $users['image']=Router::url('/upload/userProfile/thumb/'.$users['image'],true); 
				   }
        $this->set([
            'success' => true,
            
                'userdetails' =>$users
           ,
            '_serialize' => ['success', 'userdetails']
        ]);
    }
	public function logout(){
		$this->set([
            'success' => true,
            
                'msg' =>'Successfully logout',
				'code'=>200
           ,
            '_serialize' => ['success', 'msg','code']
        ]);
		
		}
	public function forgotPassword(){
			
			 $email1=$this->request->data['email'];
			
			if(!empty($email1)){
			$userData=$this->Users->find()->where(['email'=>$email1]);
			if($userData->count()>0){
				$userDataResult=$userData->toArray();
				$user=$this->Users->get($userDataResult[0]['id']);
				$newpass='Ab@'.rand(100000,1000000);
				$user->password=$newpass;
				
					if ($this->Users->save($user)) {
						$subject='New Password';
						$body="<p>Hi </p>";
						$body .="<p> Please login with this new password . you can change your password before login  </p>";
						$body .="<p>Your new password is ".$newpass."</p>";
						$body .="<p>Thank you</p>";
						$email['body']=$body;
			
						try {
							$Email = new Email();
							$Email->from(array('noreply@keneo.com' => 'Registeration'));
							$Email->emailFormat('html');
							$Email->to($email1);
							$Email->subject($subject);
							$Email->send($body);
						
						} catch (Exception $e) {
						
							echo 'Exception : ',  $e->getMessage(), "\n";
						
						}
			
						$this->set([
						'success' => true,
						
						'msg' =>'New password  has been send your email successfully.',
						'code'=>200
						,
						'_serialize' => ['success', 'msg','code']
						]);
					} else {
						$this->set([
						'success' => false,
						
						'msg' =>'Password not send your email .please try again.',
						'code'=>200
						,
						'_serialize' => ['success', 'msg','code']
						]);
					
					}
				}else{
					$this->set([
					'success' => false,
					
					'msg' =>'Password not send your email .please try again.',
					'code'=>200
					,
					'_serialize' => ['success', 'msg','code']
					]);
				
				}
			
			}
							
			
			}
        public function updateUserLocation(){
            $success = false;
            $message = "";
            $jsonData = $this->request->input('json_decode');
            try{
                $user = $this->Users->get($this->Auth->user("id"));
                $user->latitude = $jsonData->latitude;
                $user->longitude = $jsonData->longitude;
                $this->save($user);
                $success = true;
                $message = "location updated.";
            } catch (\Exception $e) {

            }
        }
}